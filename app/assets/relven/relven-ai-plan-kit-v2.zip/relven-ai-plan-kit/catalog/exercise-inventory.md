# Bundled exercise inventory

116 bundled exercises · library revision 2

This is a quick index. `exercise-library-v1.json` is canonical for IDs, revisions, instructions, equipment, and all other fields.
Use only active exercises whose canonical `equipment` array is empty when creating no-equipment workouts.

| Svenska | English | Exercise ID | Category | Movement pattern | Muscle groups | Equipment |
|---|---|---|---|---|---|---|
| 90/90 inåtrotation | 90/90 hip internal rotation | `31cbedf6-f7d7-41f6-b7c7-c9f368d24406` | warmup_mobility | hip_internal_rotation | hips | None |
| Adduktorrockning | Adductor rock-back | `f832d36c-aff4-48f5-aca4-34d978f4f5b5` | warmup_mobility | adductor_rockback | hips | None |
| Arm- och skuldercirklar | Arm and shoulder circles | `ba921ea0-b979-4372-b57d-37d8447ad61b` | warmup_mobility | shoulder_circles | shoulders, back | None |
| Armhävning | Push-up | `09a2a7b3-0798-4ef8-98a8-02a446068ee0` | upper_body | push | chest, triceps, shoulders | None |
| Armhävning på knä | Knee push-up | `a3ac8fc8-fbbc-4284-a968-737494a8f0ef` | upper_body | push | chest, triceps, shoulders | None |
| Axelböjning mot vägg | Wall shoulder-flexion isometric | `c3968918-5021-4d51-8187-d0be85cfab6e` | upper_body | shoulder_flexion_isometric | shoulders | None |
| Bakåtutfall | Reverse lunge | `584a307a-9b1f-4be8-8a25-ea8800d0ff55` | lower_body | lunge | quadriceps, glutes | None |
| Bakåtutfall med knälyft | Reverse lunge to knee drive | `52f0d5cc-eeba-4b90-b077-95c5bf2e16f2` | lower_body | reverse_lunge_knee_drive | quadriceps, glutes, abdominals | None |
| Bensving fram och bak | Front-to-back leg swing | `5e53c069-61b2-4d28-b836-5f934c1f67f3` | warmup_mobility | dynamic_hip_flexion_extension | hips, hamstrings | None |
| Bensving i sidled | Side-to-side leg swing | `8931fdfb-8fc8-45a0-b141-e3417f52d88c` | warmup_mobility | dynamic_hip_abduction_adduction | hips | None |
| Bergsklättrare | Mountain climber | `566b7625-6ad7-4b31-aa50-399795388855` | core | dynamic_core | abdominals, shoulders | None |
| Björngång | Bear crawl | `4f0a79b4-d4c4-4b66-86d6-9c6fdade25fe` | core | bear_crawl | abdominals, shoulders, hips | None |
| Björnhåll | Bear hover hold | `f9731087-43c2-40f6-bf4a-62138a111860` | core | bear_hover | abdominals, shoulders | None |
| Bred knäböj | Wide-stance squat | `cebf146c-b9c5-4eb7-869f-9855ee4a72df` | lower_body | wide_squat | quadriceps, glutes, hips | None |
| Bred knärockning | Wide-knee rock-back | `1adcb28c-e8ef-40bb-85de-320d1992cabf` | warmup_mobility | wide_knee_rockback | hips | None |
| Bröstryggsrotation på sidan | Side-lying thoracic rotation | `a29cf6ab-f926-4122-8e76-61528b1d0770` | warmup_mobility | thoracic_rotation | back, obliques | None |
| Böjt adduktorlyft | Bent-knee hip adduction | `f6e6428f-6c02-4226-b955-0836e19e15b1` | lower_body | bent_knee_hip_adduction | hips | None |
| Dead bug | Dead bug | `d99ad912-22e5-44eb-9e55-462005238910` | core | anti_extension | abdominals | None |
| Dead bug med bensträck | Dead bug leg extension | `7c788f1b-520b-4776-b85f-a7c01a628b33` | core | dead_bug_long_lever | abdominals | None |
| Dead bug med hältryck | Dead bug heel tap | `c826444c-8c80-454e-ae20-79a61c68731e` | core | dead_bug_heel_tap | abdominals | None |
| Enbens fotledsbalans | Single-leg ankle balance | `40c4f176-230f-45c3-aabe-a58244112f47` | lower_body | single_leg_balance | calves, hips | None |
| Enbens höftabduktion | Single-leg hip abduction | `aea36344-1ad2-4cbd-bf66-ba3016b2baa5` | lower_body | standing_hip_abduction | hips, glutes | None |
| Enbens höftlyft med hälgång | Single-leg bridge walkout | `801b16e3-9859-4468-b538-2008af40dcb7` | lower_body | single_leg_bridge_walkout | hamstrings, glutes | None |
| Enbens knäböj till tå | Single-leg squat and reach | `f41d7659-5195-4ddf-a531-9abb68cb9797` | lower_body | single_leg_squat_reach_forward | quadriceps, glutes, hips | None |
| Enbens tåhävning | Single-leg calf raise | `ad4f85ad-4cd4-4e87-b97a-e57f5763bb1c` | lower_body | single_leg_calf_raise | calves | None |
| Enbens tåhävning med böjt knä | Single-leg bent-knee calf raise | `c35e791e-b520-4665-ac91-39907767a193` | lower_body | single_leg_bent_knee_calf_raise | calves | None |
| Enbens tåstudsar | Single-leg pogo hops | `942fc794-680e-429f-873b-cc4d7be6920f` | lower_body | single_leg_pogo | calves, hips | None |
| Enbenshöftfällning med räckning | Single-leg hinge reach | `a80fd433-89a8-4686-8f31-6b3cd7da1601` | lower_body | single_leg_hinge_reach | hamstrings, glutes | None |
| Enbenshöftlyft | Single-leg glute bridge | `091886ef-635d-4568-954a-ef3f70e8df24` | lower_body | single_leg_bridge | glutes, hamstrings | None |
| Enbensknäböj, grund | Shallow single-leg squat | `1881c916-13c3-4903-9a71-19a8d5629f7e` | lower_body | single_leg_squat | quadriceps, glutes | None |
| Excentrisk hälsänkning | Eccentric heel lowering | `45afe6a0-7b66-42d3-8a1d-45336e01ead2` | lower_body | eccentric_calf_lowering | calves | None |
| Fotledscirklar | Ankle circles | `b84919ca-c58d-4462-8b4a-ec9b7cd744f4` | warmup_mobility | ankle_circles | calves | None |
| Fotledspress inåt och utåt | Self-resisted ankle inversion and eversion | `0614205c-04da-4086-9f26-4ef76cc3a51a` | lower_body | ankle_inversion_eversion | calves | None |
| Framåtutfall | Forward lunge | `9d5d7b0e-5871-4230-bcac-53ef7241f9b2` | lower_body | forward_lunge | quadriceps, glutes | None |
| Fyrfota höftsträckning | Quadruped hip extension | `d03ddd51-5294-4c67-bcbc-89add5185bd0` | lower_body | quadruped_hip_extension | glutes, hamstrings, abdominals | None |
| Fågelhund | Bird dog | `af39b3fd-304e-47a2-a22e-3f10f0063f6d` | core | contralateral_stability | back, abdominals, glutes | None |
| Fågelhund med knädrag | Bird dog knee drive | `06144fd2-aad9-4ad2-afc1-f44018706d88` | core | bird_dog_knee_to_elbow | back, abdominals, glutes | None |
| Gående hamstringsvep | Walking hamstring sweep | `74793676-4f2a-44aa-b833-16aa7ad62afc` | warmup_mobility | dynamic_hamstring_mobility | hamstrings | None |
| Gående knälyft | Marching knee raise | `c444dd89-62fa-425b-955e-567c4b853241` | warmup_mobility | march | hips, abdominals | None |
| Hollow body-håll | Hollow body hold | `013cb4dd-adf7-498d-9267-1102eab7f822` | core | hollow_body_hold | abdominals | None |
| Hollow tuck-håll | Hollow tuck hold | `f17c2ef9-b57f-4dff-b35b-cd945dc7cfb6` | core | hollow_body_tuck | abdominals | None |
| Hälpress mot golvet | Supine heel press | `8ccb6c9c-8c3e-4e49-849a-cee683619e70` | lower_body | hamstring_isometric | hamstrings, glutes | None |
| Höftfällning | Hip hinge | `1d8dbf3c-e768-4876-935d-d90881fb87e4` | warmup_mobility | hinge | hamstrings, glutes | None |
| Höftfällning med stödben | Kickstand hip hinge | `e2afb474-1414-46fa-833d-f82c9c02b515` | lower_body | kickstand_hinge | hamstrings, glutes | None |
| Höftgrindar | Hip open-and-close gates | `c36cdebc-cd7b-4a99-9b35-b2980d07afce` | warmup_mobility | hip_gate_mobility | hips | None |
| Höftlyft | Glute bridge | `a112bc26-c38c-45c8-a855-6bb8b412daf2` | lower_body | hip_extension | glutes, hamstrings | None |
| Höftlyft med lång hävarm | Long-lever bridge | `1a8ffbc7-e4c4-45fc-b405-33b837315fc1` | lower_body | long_lever_bridge | hamstrings, glutes | None |
| Höftlyft med marsch | Glute bridge march | `2a8d1a7a-be56-4d37-9ad9-d1facd0870d2` | lower_body | bridge_march | glutes, hamstrings, abdominals | None |
| Höftlyft med utgång | Bridge walkout | `0509c4b3-a679-4641-9d96-2f11a94e8e8b` | lower_body | bridge_walkout | hamstrings, glutes | None |
| Inåtrotation mot vägg | Wall internal-rotation isometric | `eaf0a421-5b39-46fe-9e78-0e6a2da0e5a9` | upper_body | shoulder_internal_rotation_isometric | shoulders | None |
| Jumping jack | Jumping jack | `2e65df65-017b-4fbb-9c02-ecc5ca64fc4f` | warmup_mobility | cardiovascular | calves, shoulders | None |
| Knä fram över tå | Knee-to-toe ankle mobility | `11d7c089-78bb-45d1-9f72-680f200d8f62` | warmup_mobility | ankle_dorsiflexion_mobility | calves | None |
| Knäböj | Bodyweight squat | `3b0e6f4b-9252-4e8c-96e5-7df5e0bb18d0` | lower_body | squat | quadriceps, glutes | None |
| Knäböj med sidräckning | Single-leg squat with reach | `656213fd-5e06-43cc-aa2f-ac8757a32a91` | lower_body | single_leg_squat_reach | quadriceps, glutes, hips | None |
| Knäböj med tåhävning | Squat to calf raise | `6345ee07-e274-49c1-9538-6f6bdeabd7d2` | lower_body | squat_to_calf_raise | quadriceps, glutes, calves | None |
| Knäböjshopp med landning | Squat jump and stick | `084bbffa-0f99-4b8e-9c08-7ab2247a9483` | lower_body | bilateral_jump_landing | quadriceps, glutes, calves | None |
| Kortfot | Short-foot exercise | `1724c268-0e13-4af6-8d0f-39116e164491` | lower_body | intrinsic_foot_control | calves | None |
| Landning till atletisk position | Snap-down landing | `1349131c-2110-480b-ab14-bdd6f3b3e169` | lower_body | landing_mechanics | quadriceps, glutes, calves | None |
| Lång planka | Long-lever plank | `5410b7b3-4399-4286-801a-057d864506db` | core | long_lever_anti_extension | abdominals, shoulders | None |
| Långt höftlyft med håll | Long-lever bridge hold | `562bd1ab-53e7-4f44-9be9-ae84af6fdaa2` | lower_body | long_lever_bridge_hold | hamstrings, glutes | None |
| Magliggande häldrag | Prone heel drag | `68b0b97b-bf58-4168-af85-6fe290589d42` | lower_body | prone_hamstring_isometric | hamstrings | None |
| Magliggande T-lyft | Prone T lift | `7c9fda77-4dae-4c86-a37f-165c000c3fcb` | upper_body | scapular_retraction | back, shoulders | None |
| Magliggande W-lyft | Prone W lift | `017c6dfb-80c9-4b11-a445-0d5e9b19a0fe` | upper_body | scapular_external_rotation | back, shoulders | None |
| Magliggande Y-lyft | Prone Y lift | `9faad62f-32a3-4cfc-a36f-62a8c563e80d` | upper_body | scapular_elevation_control | back, shoulders | None |
| Omvänd magcurl | Reverse crunch | `30f654d9-2e8d-4959-896b-ed4c6ec72729` | core | reverse_crunch | abdominals | None |
| Planka med axelklapp | Plank shoulder tap | `e6f4fa51-f767-425c-8bf2-34ede35a7541` | core | plank_anti_rotation | abdominals, shoulders | None |
| Planka på underarmarna | Forearm plank | `b3dff0aa-e44b-4c53-9519-dd99a032a19a` | core | anti_extension | abdominals, shoulders | None |
| Serratusreach på rygg | Supine serratus reach | `37e8b11c-a6e1-4149-a08f-c8ddf602c91e` | upper_body | supine_serratus_reach | shoulders, chest | None |
| Sidliggande adduktorlyft | Side-lying hip adduction | `90fa40e4-5b0b-4f59-bcbc-b07697df6879` | lower_body | side_lying_hip_adduction | hips | None |
| Sidliggande höftrotation | Side-lying hip rotation | `8b88f775-b38f-4732-9f42-83b2b51fdb65` | lower_body | side_lying_hip_rotation | hips | None |
| Sidoplanka | Side plank | `be1a39c1-1675-467e-a5ca-e4352ac87809` | core | lateral_stability | obliques, shoulders | None |
| Sidoplanka med benlyft | Side plank with leg lift | `e3a43638-290c-43f8-8699-a74ad7f26bd4` | core | side_plank_hip_abduction | obliques, hips | None |
| Sidoplanka med rotation | Side plank thread-through | `488a2cdb-5f95-4aa3-ab30-a69230efe31b` | core | side_plank_rotation | obliques, abdominals | None |
| Sidoplanka på knä | Kneeling side plank | `fe27ada2-478d-4654-ae38-85c6462eba76` | core | kneeling_lateral_stability | obliques, abdominals | None |
| Sidosteg i djup position | Low lateral shuffle step | `424b5301-b79e-4ba1-b056-219550daadff` | lower_body | lateral_shuffle_step | hips, quadriceps | None |
| Sidoutfall | Lateral lunge | `62345244-eae1-4ae4-beb9-b491fef05a9c` | lower_body | lateral_lunge | quadriceps, glutes, hips | None |
| Sidoutfall med viktförskjutning | Lateral weight shift | `8dd03213-d267-4ef5-b75c-8b7ef3253457` | lower_body | lateral_weight_shift | hips, quadriceps | None |
| Sidoutfall till balans | Lateral lunge to balance | `0386f6b5-be04-4f7f-92b9-ebb0a85205ed` | lower_body | lateral_lunge_balance | quadriceps, glutes, hips | None |
| Sittande tålyft | Seated toe raise | `2dfd9494-8dc5-4ea5-a28d-3b8c4707ad79` | lower_body | seated_dorsiflexion | calves | None |
| Självmotstånd för fotlyft | Self-resisted dorsiflexion | `4c698272-315f-4d68-b9aa-b2082c4d2b4b` | lower_body | self_resisted_dorsiflexion | calves | None |
| Självmotstånd inåtrotation | Self-resisted shoulder internal rotation | `3d4acc7f-f7a1-4f8b-a8fd-e1a41ccbf5c7` | upper_body | shoulder_internal_rotation | shoulders | None |
| Självmotstånd utåtrotation | Self-resisted shoulder external rotation | `03b9ad14-d869-4d1f-956e-d9a5cc13fbc9` | upper_body | shoulder_external_rotation | shoulders | None |
| Självpress för adduktorer | Self-resisted hip adduction | `8df10410-416a-40b2-bc06-e5fb2b804322` | lower_body | self_resisted_adduction | hips | None |
| Skridskohopp med stopp | Skater hop and stick | `96cc881d-da0a-4c9f-9523-756ce20e1d85` | lower_body | lateral_bound_stick | glutes, hips, quadriceps | None |
| Skridskosteg | Skater step | `0016fdc3-6c8b-418c-a8c8-49095c114ea1` | lower_body | lateral_bound_step | glutes, hips, quadriceps | None |
| Skulderbladspush-up | Scapular push-up | `790f6b83-cb25-4de1-87e8-95d446f82878` | upper_body | scapular_push | shoulders, chest | None |
| Smal knäböj | Narrow-stance squat | `3489b838-36c5-43e6-a57c-2f7dbdfbd697` | lower_body | narrow_squat | quadriceps, glutes | None |
| Små hopp fram och tillbaka | Low forward-back hops | `6bf21a40-e2f4-4396-9fcf-d37a6f5ecc30` | lower_body | forward_backward_hop | calves, quadriceps | None |
| Små sidledshopp | Low lateral line hops | `fecfcad4-1786-4862-a781-6aa3d9931d5d` | lower_body | lateral_hop | calves, hips | None |
| Små tåstudsar | Low pogo hops | `7f502d71-3931-4ef1-9534-bc0727f9ad2f` | lower_body | bilateral_pogo | calves | None |
| Split squat-håll | Split squat isometric hold | `ce393329-74b8-405d-8eb6-055244f2b451` | lower_body | split_squat_isometric | quadriceps, glutes | None |
| Sprintposition mot vägg | Wall sprint-drive | `98d288d1-735b-4a82-bc3a-d9e2c97e0bc9` | lower_body | acceleration_wall_drive | glutes, hamstrings, abdominals | None |
| Statisk split squat | Split squat | `e7dc9206-9774-4785-9dcb-f4156003e786` | lower_body | split_squat | quadriceps, glutes | None |
| Stående bröstryggsrotation | Standing thoracic rotation | `e68135e6-e4fc-4ba9-9c7a-2eaf5d44ae10` | warmup_mobility | standing_thoracic_rotation | back, obliques | None |
| Stående framsida lår | Standing quad stretch | `5c778d2a-2be6-4366-8f10-72786048d8db` | warmup_mobility | static_stretch | quadriceps | None |
| Stående höftadduktion | Standing hip adduction | `2166b66a-eb3f-4daf-b340-84e3d2df813e` | lower_body | standing_hip_adduction | hips | None |
| Stående höftsträckning | Standing hip extension | `6b56e2f7-4158-4bb2-9c0b-4a1131c328e9` | lower_body | standing_hip_extension | glutes, hamstrings | None |
| Tibialislyft mot vägg | Wall tibialis raise | `875ccdd9-a028-4235-8f3d-9a517de2577f` | lower_body | tibialis_raise | calves | None |
| Tre steg och kontrollerat stopp | Three-step acceleration and stop | `eb7357dd-7f4d-4042-bb1f-455eb169dcde` | lower_body | acceleration_deceleration | quadriceps, glutes, calves | None |
| Tåhävning | Calf raise | `78a2e792-7974-495b-80dd-c21c842890ab` | lower_body | calf_raise | calves | None |
| Tåhävning med böjt knä | Bent-knee calf raise | `dd6db5ec-542b-478f-8fbc-f3babb27e11e` | lower_body | bent_knee_calf_raise | calves | None |
| Tåhävningshåll | Calf raise hold | `3f1dd088-341a-433d-b6ec-2bbc74065ac9` | lower_body | calf_raise_isometric | calves | None |
| Tåspridning | Toe spreading | `9f88562e-a2c0-40c6-9796-4e089b35d079` | warmup_mobility | toe_spread | calves | None |
| Tåyoga | Toe yoga | `ba1380d2-363b-44da-9b51-5afb79f941d2` | warmup_mobility | toe_control | calves | None |
| Underarmsplanka med knälyft | Forearm plank knee lift | `969e3071-d933-4402-a76c-6848ca25ef69` | core | plank_hip_extension | abdominals, glutes | None |
| Utfall bakåt med pendel | Reverse lunge with hip hinge | `85d3e7b0-851c-47a2-b2c7-4e5c49f767fd` | lower_body | reverse_lunge_hip_hinge | glutes, hamstrings, quadriceps | None |
| Utfall med sidolutning | Lateral lunge with reach | `366b0f3f-a09d-474e-9fc0-5402b11132c1` | lower_body | lateral_lunge_reach | hips, quadriceps, obliques | None |
| Utfallssteg bakåt | Step-back lunge | `91e4c7d4-cbf1-415b-ae04-e659f162c9bd` | lower_body | step_back_lunge | quadriceps, glutes | None |
| Väggarmhävning | Wall push-up | `e23753e0-07db-4aa2-b5f6-40577b16f128` | upper_body | wall_push | chest, shoulders, triceps | None |
| Väggglidning | Wall slide | `82044bbc-c86c-46eb-96ea-031d821b5ff4` | upper_body | wall_slide | shoulders, back | None |
| Väggpress med skulderblad | Wall push-up plus | `4c387eb3-b7db-4c78-bb79-b056fc7cb08e` | upper_body | wall_serratus_press | shoulders, chest | None |
| Väggpress med viktförskjutning | Wall plank weight shift | `5f040539-4d73-45d3-b644-65923308677b` | upper_body | wall_closed_chain_stability | shoulders, abdominals | None |
| Väggsittning | Wall sit | `101a9b68-62c3-47a4-a619-2073893303c2` | lower_body | isometric_squat | quadriceps, glutes | None |
| Väggsittning med tålyft | Wall sit with toe lift | `9736a98b-6fee-4d60-8b81-a366394431b4` | lower_body | wall_sit_tibialis_raise | quadriceps, calves | None |
| Väggängel | Wall angel | `f471b7ca-f63a-4995-afd0-09e0a309345b` | upper_body | wall_angel | shoulders, back | None |
| Växlande sidoutfall | Alternating lateral lunge | `888f94d2-58a9-4c7f-98c4-0a2796f6ff54` | lower_body | alternating_lateral_lunge | quadriceps, glutes, hips | None |
